#include <stdio.h>

int subtrai(int,int);

int main (){
    int num = subtrai(3,2);
    printf("3 - 2 = %d", num);
    return 0;

}